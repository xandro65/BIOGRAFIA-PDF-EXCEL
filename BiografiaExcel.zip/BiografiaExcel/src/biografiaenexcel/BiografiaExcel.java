package biografiaenexcel;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.sl.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class BiografiaExcel {

    
    public static void Excel() {

        Workbook w = new XSSFWorkbook();
        org.apache.poi.ss.usermodel.Sheet sheet = w.createSheet("Excel");

        Row t = sheet.createRow(0);
        t.createCell(0).setCellValue("EDUARDO ALEJANDRO LOPEZ LOPEZ");
        
        Row t1 = sheet.createRow(1);
        t1.createCell(0).setCellValue("NACI EL 16 DE OCTUBRE EN TOLUCA ESTADO DE MEXICO,");
        
        Row t2 = sheet.createRow(2);
        t2.createCell(0).setCellValue("CRECI Y A LOS 2 AÑOS FUI BENDCIDO CON UN HERMANO EL CUAL ES MUY PAYASO");
        
        Row t3 = sheet.createRow(3);
        t3.createCell(0).setCellValue("NO ES COMO ANTES PERO AUN ASI LO QUIERO MUCHO,");
        
        Row t4 = sheet.createRow(4);
        t4.createCell(0).setCellValue("CUANDO TENIA 4 AÑOS NACIO MI OTRO HERMANO EL CUAL LE HACIA MUCHAS,");
        
        Row t5 = sheet.createRow(5);
        t5.createCell(0).setCellValue("MALDADES, DESPUES DE 6 AÑOS SALIMOS DE VACACIONES A ZACATECAS Y ALLI NOS ");
        
        Row t6 = sheet.createRow(6);
        t6.createCell(0).setCellValue("DIVERTIMOS MUCHO Y NOS QUEDAMOS COMO 3 MESES, DESAFORTUNADAMENTE NOS TUVIMOS QUE ");

        Row t7 = sheet.createRow(7);
        t7.createCell(0).setCellValue("REGRESAR PORUE UN MOSCO ME PICO LA MEJILLA Y DEL CUAL NO AGUANTE LA PICAZON Y ME SALIO UN ENORME GRANO");

        Row t8 = sheet.createRow(8);
        t8.createCell(0).setCellValue("Y ME LLEVARON AL MEDICO Y ME TUVIERON QUE DAR MUCHO ANTIVIOTICO PARA PODER SANAR MI MEJILLA");

        Row t9 = sheet.createRow(9);
        t9.createCell(0).setCellValue("LASTIMADA, Y AHORA ODIO A LOS MOSQUITOS, Y POR TAL MOTIVO YA NO SALIMOS DE VACACIONES");

        Row t10 = sheet.createRow(10);
        t10.createCell(0).setCellValue("CUANDO TENIA 6 AÑOS INGRESE A LA PRIMARIA MIGUEL HIDALGO Y COSTILLA Y FUI MUY FELIZ DURANTE LA,");

        Row t11 = sheet.createRow(11);
        t11.createCell(0).setCellValue("PRIMARIA, Y ALLY CONOCI A UNA NIÑA QUE ME GUSTABA MUCHO PERO NO ME ANIME A CONFESARLE LO QUE SENTIA POR ");
        
         Row t12 = sheet.createRow(12);
        t12.createCell(0).setCellValue("ELLA, DESPUES INGRESE A LA SECUNDARIA Y NO FUE TAN DIVERTIDO YA QUE TUVE COMPAÑEROS PROBLEMATICOS Y LUEGO ME");
        
         Row t13 = sheet.createRow(13);
        t13.createCell(0).setCellValue("DESPUES INGRESE A LA PREPARATORIA Y ME GUSTO MUCHO PORUQE CONOCI A MIS MEJORES AMIGOS QUE EN LA,");
        
         Row t14 = sheet.createRow(14);
        t14.createCell(0).setCellValue("LA ACTULIADAD NI LES HABLO JAJAJA EN ESA ETAPA SUFRI UN DESAMOR EL CUAL ME CAUSO MUCHO DOLOR Y DAÑO Y NO VOLVI A ");
        
         Row t15 = sheet.createRow(15);
        t15.createCell(0).setCellValue("A CREER EN EL AMOR, DEPSUES INGRESE A LA UNIVERSIDAD EN DONDE CONOCI A MIS AMIGOS EN LOS CUALES ME ");
        
         Row t16 = sheet.createRow(16);
        t16.createCell(0).setCellValue("ME LLEVO DE MANERA FABULOSA ESTABA ESTUDIANDO INGENIERIA EN ELECTRONICA EN EL INSTITUTO");
        
         Row t17 = sheet.createRow(17);
        t17.createCell(0).setCellValue("TECNOLOGICO DE TELUCA Y LLEGUE A SEXTO SEMESTRE Y DSAFORTUNADAMENTE NO LOGRE TERMINAR YA QUE ME FUI A ESPECIAL,");
        
         Row t18 = sheet.createRow(18);
        t18.createCell(0).setCellValue("DE CIENCIAS BASICAS Y TUVE QUE DEJAR DE IR, SENTI QUE SE ME CERRABA EL MUNDO Y ME DIO");
        
         Row t19 = sheet.createRow(19);
        t19.createCell(0).setCellValue("DEPRESION Y NO TENIA GANAS DE HACER NADA Y ME CONVERTI EN NINI DURANTE UN AÑO, DEPUES DE ESE AÑO MIS PADRES");
        
        Row t20 = sheet.createRow(20);
        t20.createCell(0).setCellValue("Y ME DIERON UNA REGAÑADA DE AQUELLAS Y ME PUSIERONUN ULTIMATUM, DONDE ERA O PONERME A TRABAJAR O REGRESABA A LA");

         Row t21 = sheet.createRow(21);
        t21.createCell(0).setCellValue("PUES ME PUSE A TRABAJAR DURANTE UN AÑO Y DESPUES DE ESE TIEMPO REGRESE A ESTUDIAR A LA");
        
         Row t22 = sheet.createRow(22);
        t22.createCell(0).setCellValue("UNIVERSIDAD TECNOLOGICA DEL VALLE DE TOLUCA Y ALLI CONOCI A LA QUE CREIA QUE ERA EL AMOR DE MI ");
        
         Row t23 = sheet.createRow(23);
        t23.createCell(0).setCellValue("VIDA Y DURAMOS 5 AAÑOS, DESAFORTUNADAMENTE TUVE QUE VOLVER A DEJAR DE IR A LA UNIVERSIDAD");
        
         Row t24 = sheet.createRow(24);
        t24.createCell(0).setCellValue("PERO ESTA VEZ NO FUE POR PROBLEMAS ACADEMICOS AHORA FUE POR DIFICULTADES ECONOMICAS YA QUE HABIA VECES,");
        
         Row t25 = sheet.createRow(25);
        t25.createCell(0).setCellValue("QUE NO ACOMPLETABA PARA EL PASAJE JAJAJAJAAJA Y VOLVI A METERME A TRABAJAR EN DONDE DURE 4 AÑOS TRABAJANDO,");
        
        Row t26 = sheet.createRow(26);
        t26.createCell(0).setCellValue("PERO DENTRO DE MI HABIA U PENSAMIENTO DE QUE TENIA QUE REGRESAR A TERMINAR Y REALICE EL EXAMEN PARA ");
        
         Row t27 = sheet.createRow(27);
        t27.createCell(0).setCellValue("LA UNIVERSIDAD AUTONOMA DEL ESTADO DE MEXICO EN LA CARRERA DE INGENIERIA EN COMPUTACION");
        
         Row t28 = sheet.createRow(28);
        t28.createCell(0).setCellValue("Y AHORA ME ENCUENTRO EN EL TERCER SEMESTRE NO VOY COMO DESEARIA PERO ALLI LA LLEVO Y PRIMERO DIOS");
        
         Row t29 = sheet.createRow(29);
        t29.createCell(0).setCellValue("TERMINARE AHORA SI LA UNIVERSODAD PARA PODER SEGURI CON EL SIGUEINTE PROYECTO");
        
         Row t30 = sheet.createRow(30);
        t30.createCell(0).setCellValue("AHH TAMBIEN TRABAJO Y ME ESTA COSTANDO TRABAJO PERO SE QUE SE LOGRARA EL PROPOSITO.");
        
        try {
            
            FileOutputStream f = new FileOutputStream("BiografiaExcel.xlsx");
            w.write(f);
            f.close();
            
        } catch (FileNotFoundException ex) {
            
            Logger.getLogger(BiografiaExcel.class.getName()).log(Level.SEVERE, null, ex);
            
        } catch (IOException ex) {
            
            Logger.getLogger(BiografiaExcel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        JOptionPane.showMessageDialog(null,"EXCEL CREADO");
    }
    
    public static void main(String[] args) {

        Excel();
    }

}
