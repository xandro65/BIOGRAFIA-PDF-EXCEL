
package biografia;

import com.itextpdf.io.font.FontConstants;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import java.io.IOException;
import javax.swing.JOptionPane;


public class BiografiaPDF {
     
    public static final String destino = "/Users/eduardoalejandrolopezlopez/Library/Mobile Documents/com~apple~CloudDocs"; 
    public static final String foto = "/Users/eduardoalejandrolopezlopez/Library/Mobile Documents/com~apple~CloudDocs";
   
    
    
    public void pdf(String dest) throws IOException{
        
    PdfWriter w = new PdfWriter(dest);
    
    PdfDocument pdf = new PdfDocument(w);
    
    Document doc = new Document(pdf);
    
    Image fotografia = new Image(ImageDataFactory.create(foto));   
  
    
    PdfFont f = PdfFontFactory.createFont(FontConstants.TIMES_ITALIC);
    
    
    Paragraph texto = new Paragraph("EDUARDO ALEJANDRO LOPEZ LOPEZ")
                    .add(fotografia)
                    .add("\nNACI EL 16 DE OCTUBRE EN TOLUCA ESTADO DE MEXICO,"
                            + "CRECI Y A LOS 2 AÑOS FUI BENDCIDO CON UN HERMANO EL CUAL ES MUY PAYASO"
                            + "NO ES COMO ANTES PERO AUN ASI LO QUIERO MUCHO, "
                            + "CUANDO TENIA 4 AÑOS NACIO MI OTRO HERMANO EL CUAL LE HACIA MUCHAS,"
                            + "MALDADES, DESPUES DE 6 AÑOS SALIMOS DE VACACIONES A ZACATECAS Y ALLI NOS"
                            + "DIVERTIMOS MUCHO Y NOS QUEDAMOS COMO 3 MESES, DESAFORTUNADAMENTE NOS TUVIMOS QUE"
                            + "REGRESAR PORUE UN MOSCO ME PICO LA MEJILLA Y DEL CUAL NO AGUANTE LA PICAZON Y ME SALIO UN ENORME GRANO"
                            + "Y ME LLEVARON AL MEDICO Y ME TUVIERON QUE DAR MUCHO ANTIVIOTICO PARA PODER SANAR MI MEJILLA"
                            + "LASTIMADA, Y AHORA ODIO A LOS MOSQUITOS, Y POR TAL MOTIVO YA NO SALIMOS DE VACACIONES"
                            + "CUANDO TENIA 6 AÑOS INGRESE A LA PRIMARIA MIGUEL HIDALGO Y COSTILLA Y FUI MUY FELIZ DURANTE LA,"
                            + "PRIMARIA, Y ALLY CONOCI A UNA NIÑA QUE ME GUSTABA MUCHO PERO NO ME ANIME A CONFESARLE LO QUE SENTIA POR "
                            + "ELLA, DESPUES INGRESE A LA SECUNDARIA Y NO FUE TAN DIVERTIDO YA QUE TUVE COMPAÑEROS PROBLEMATICOS Y LUEGO ME "
                            + "DESPUES INGRESE A LA PREPARATORIA Y ME GUSTO MUCHO PORUQE CONOCI A MIS MEJORES AMIGOS QUE EN LA,"
                            + "LA ACTULIADAD NI LES HABLO JAJAJA EN ESA ETAPA SUFRI UN DESAMOR EL CUAL ME CAUSO MUCHO DOLOR Y DAÑO Y NO VOLVI A "
                            + " A CREER EN EL AMOR, DEPSUES INGRESE A LA UNIVERSIDAD EN DONDE CONOCI A MIS AMIGOS EN LOS CUALES ME"
                            + "ME LLEVO DE MANERA FABULOSA ESTABA ESTUDIANDO INGENIERIA EN ELECTRONICA EN EL INSTITUTO"
                            + "ECNOLOGICO DE TELUCA Y LLEGUE A SEXTO SEMESTRE Y DSAFORTUNADAMENTE NO LOGRE TERMINAR YA QUE ME FUI A ESPECIAL "
                            + " DE CIENCIAS BASICAS Y TUVE QUE DEJAR DE IR, SENTI QUE SE ME CERRABA EL MUNDO Y ME DIO"
                            + " DEPRESION Y NO TENIA GANAS DE HACER NADA Y ME CONVERTI EN NINI DURANTE UN AÑO, DEPUES DE ESE AÑO MIS PADRES" 
                            + " Y ME DIERON UNA REGAÑADA DE AQUELLAS Y ME PUSIERONUN ULTIMATUM, DONDE ERA O PONERME A TRABAJAR O REGRESABA A LA"
                            + " PUES ME PUSE A TRABAJAR DURANTE UN AÑO Y DESPUES DE ESE TIEMPO REGRESE A ESTUDIAR A LA  "
                            + "UNIVERSIDAD TECNOLOGICA DEL VALLE DE TOLUCA Y ALLI CONOCI A LA QUE CREIA QUE ERA EL AMOR DE MI "
                            + "VIDA Y DURAMOS 5 AAÑOS, DESAFORTUNADAMENTE TUVE QUE VOLVER A DEJAR DE IR A LA UNIVERSIDAD"
                            + "PERO ESTA VEZ NO FUE POR PROBLEMAS ACADEMICOS AHORA FUE POR DIFICULTADES ECONOMICAS YA QUE HABIA VECES"
                            + "QUE NO ACOMPLETABA PARA EL PASAJE JAJAJAJAAJA Y VOLVI A METERME A TRABAJAR EN DONDE DURE 4 AÑOS TRABAJANDO"
                            + "PERO DENTRO DE MI HABIA U PENSAMIENTO DE QUE TENIA QUE REGRESAR A TERMINAR Y REALICE EL EXAMEN PARA"
                            + "LA UNIVERSIDAD AUTONOMA DEL ESTADO DE MEXICO EN LA CARRERA DE INGENIERIA EN COMPUTACION"
                            + "Y AHORA ME ENCUENTRO EN EL TERCER SEMESTRE NO VOY COMO DESEARIA PERO ALLI LA LLEVO Y PRIMERO DIOS "
                            + "TERMINARE AHORA SI LA UNIVERSODAD PARA PODER SEGURI CON EL SIGUEINTE PROYECTO "
                            + "AHH TAMBIEN TRABAJO Y ME ESTA COSTANDO TRABAJO PERO SE QUE SE LOGRARA EL PROPOSITO.");
                    
              
    
    doc.add(texto);
    doc.close();
    
    
    JOptionPane.showMessageDialog(null,"PDF CREADO");       
        
    }
    public static void main(String[] args) throws IOException {
        
        new BiografiaPDF().pdf(destino);
        
        
    }
}
